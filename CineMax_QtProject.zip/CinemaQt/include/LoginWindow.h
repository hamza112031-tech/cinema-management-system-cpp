#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include <QWidget>
#include <QComboBox>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>

class LoginWindow : public QWidget {
    Q_OBJECT
public:
    explicit LoginWindow(QWidget* parent = nullptr);

signals:
    void loginSuccess(const QString& role);

private:
    QComboBox*   roleBox;
    QLineEdit*   usernameEdit;
    QLineEdit*   passwordEdit;
    QPushButton* loginBtn;
    QLabel*      errorLabel;

private slots:
    void onLogin();
};

#endif // LOGINWINDOW_H
