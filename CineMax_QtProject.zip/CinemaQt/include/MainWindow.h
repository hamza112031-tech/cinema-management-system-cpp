#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QListWidget>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include "CinemaSystem.h"

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);

private:
    Cinema cinema;

    QWidget*       sidebar;
    QStackedWidget* stack;
    QLabel*        pageTitle;
    QListWidget*   navList;

    // pages
    QWidget* makeDashboardPage();
    QWidget* makeMoviesPage();
    QWidget* makeHallsPage();
    QWidget* makeTicketsPage();
    QWidget* makeEmployeesPage();
    QWidget* makeFinancePage();
    QWidget* makeSnackPage();
    QWidget* makeParkingPage();

    // helpers
    QFrame* card(QWidget* parent = nullptr);
    QLabel* sectionTitle(const QString& text);
    QPushButton* primaryBtn(const QString& text);
    QPushButton* navBtn(const QString& icon, const QString& label, int page);
    QWidget* statCard(const QString& label, const QString& value, const QString& color);

    void applyTheme();
    void setupSidebar();
    void setupTopBar();

    int currentPage = 0;

private slots:
    void onNavClicked(int page);
};

#endif // MAINWINDOW_H
