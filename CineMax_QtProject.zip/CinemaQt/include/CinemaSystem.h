#ifndef CINEMASYSTEM_H
#define CINEMASYSTEM_H

#include <QString>
#include <QVector>

// ================= MOVIE =================
struct Movie {
    QString name;
    QString origin;
    QString genre;
    double  price;
    QVector<QString> showtimes;

    Movie() : price(0) {}
    Movie(QString n, QString o, QString g, double p)
        : name(n), origin(o), genre(g), price(p) {}

    void addShowtime(const QString& t) { showtimes.append(t); }
};

// ================= HALL =================
struct Hall {
    QString name;
    QString type;   // "VIP" | "Normal"
    QString screen; // "2D" | "3D" | "VR"
    int     capacity;

    Hall() : capacity(0) {}
    Hall(QString n, QString t, QString s, int c)
        : name(n), type(t), screen(s), capacity(c) {}
};

// ================= EMPLOYEE =================
struct Employee {
    QString name;
    QString position;
    double  dailyRate;
    int     daysWorked;

    Employee() : dailyRate(0), daysWorked(0) {}
    Employee(QString n, QString p, double r)
        : name(n), position(p), dailyRate(r), daysWorked(0) {}

    double salary() const { return dailyRate * daysWorked; }
};

// ================= TICKET =================
struct Ticket {
    QString movieName;
    QString showtime;
    QString hallType;
    int     seatNumber;
    bool    isWeekend;
    double  price;

    Ticket() : seatNumber(0), isWeekend(false), price(0) {}
};

// ================= SNACKBAR =================
struct SnackOrder {
    int popcorn = 0;
    int drinks  = 0;
    int nachos  = 0;

    double total() const {
        return popcorn * 60 + drinks * 40 + nachos * 50;
    }
};

// ================= FINANCE =================
struct FinanceSummary {
    double ticketRevenue  = 0;
    double snackRevenue   = 0;
    double parkingRevenue = 0;
    double taxRate        = 0.14;

    double gross()  const { return ticketRevenue + snackRevenue + parkingRevenue; }
    double tax()    const { return gross() * taxRate; }
    double net()    const { return gross() - tax(); }
};

// ================= CINEMA =================
class Cinema {
public:
    QVector<Movie>    movies;
    QVector<Hall>     halls;
    QVector<Employee> employees;
    FinanceSummary    finance;

    Cinema();

    Movie*    findMovie(const QString& name);
    Employee* findEmployee(const QString& name);

    double calcParking(int minutes) const { return (minutes / 60.0) * 15.0; }
    double calcTicketPrice(const Movie& m, const QString& hallType, bool weekend) const;
};

#endif // CINEMASYSTEM_H
