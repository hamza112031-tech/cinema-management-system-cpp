# 🎬 CineMax — دليل التثبيت والتشغيل على Windows

---

## 📁 هيكل المشروع

```
CineMax/
├── CineMax.pro              ← ملف مشروع Qt
├── include/
│   ├── CinemaSystem.h
│   ├── LoginWindow.h
│   └── MainWindow.h
└── src/
    ├── main.cpp
    ├── CinemaSystem.cpp
    ├── LoginWindow.cpp
    └── MainWindow.cpp
```

---

## ⚡ الطريقة الأولى: Qt Creator (الأسهل والأسرع)

### الخطوة 1 — تحميل Qt

1. روح على: https://www.qt.io/download-qt-installer
2. اضغط **Download Qt Online Installer**
3. شغّل الـ installer واختار:
   - ✅ **Qt 6.5** (أو Qt 5.15)
   - ✅ **Qt Creator**
   - ✅ **MinGW 64-bit** (compiler)
4. خلّي التثبيت يكمّل (بياخد ~3 GB)

### الخطوة 2 — افتح المشروع

1. افتح **Qt Creator**
2. اضغط **File → Open File or Project**
3. اختار ملف `CineMax.pro`
4. اضغط **Configure Project** (اختار Kit: Desktop Qt + MinGW)

### الخطوة 3 — شغّل المشروع

```
اضغط الزر الأخضر ▶  أو اضغط Ctrl + R
```

**كده خلاص! التطبيق هيفتح ✅**

---

## 🔧 الطريقة الثانية: Command Line بدون Qt Creator

### متطلبات
- Qt مثبّت (نفس الخطوات فوق)
- MinGW في الـ PATH

```batch
:: افتح CMD وروح للمجلد
cd C:\path\to\CineMax

:: شغّل qmake عشان يعمل Makefile
qmake CineMax.pro

:: ابني المشروع
mingw32-make

:: شغّل التطبيق
release\CineMax.exe
```

---

## 🚪 بيانات الدخول

| الحقل    | القيمة    |
|----------|-----------|
| Username | admin     |
| Password | admin123  |
| Role     | Owner / Employee / Customer |

---

## ❌ مشاكل شائعة وحلّها

### مشكلة: "qmake not found"
**الحل:** أضف Qt للـ PATH:
```
C:\Qt\6.5.0\mingw_64\bin
C:\Qt\Tools\mingw1120_64\bin
```
أو ابحث في Start Menu عن "Qt 6.5 MinGW" وافتح الـ terminal منه مباشرة.

### مشكلة: "Cannot find -lQt6Widgets"
**الحل:** تأكد إنك اخترت **Qt Widgets** في الـ installer.

### مشكلة: التطبيق بيشتغل بس مفيش صور/أيقونات
**الحل:** طبيعي — المشروع مش محتاج resource files.

### مشكلة: الـ .exe مش شغّال خارج Qt Creator
**الحل:** انسخ الـ DLLs المطلوبة جنب الـ .exe:
```batch
cd release
windeployqt CineMax.exe
```
أمر `windeployqt` هيجمع كل الـ DLLs تلقائياً ✅

---

## 📦 المتطلبات الكاملة

| Component         | Version    |
|------------------|------------|
| Qt Framework     | 5.15+ أو 6.x |
| Qt Creator       | أي إصدار   |
| MinGW / MSVC     | 64-bit     |
| Windows          | 10 أو 11   |
| RAM              | 4 GB+      |
| Storage          | ~3 GB (Qt) |

---

## 🎯 مميزات الـ GUI

- ✅ Login Screen بـ 3 أدوار (Owner / Employee / Customer)
- ✅ Dashboard مع إحصائيات حية
- ✅ إدارة الأفلام (إضافة / حذف)
- ✅ إدارة القاعات والشاشات (2D/3D/VR)
- ✅ حجز تذاكر مع Seat Map تفاعلي
- ✅ إدارة الموظفين وحساب الرواتب
- ✅ تقارير مالية مع Tax Calculator
- ✅ Snack Bar مع حساب الفاتورة
- ✅ نظام الباركينج مع Slider تفاعلي
- ✅ Dark Mode احترافي (Cinema Theme)

---

*Made with Qt Widgets — OOP University Project*
