QT += core gui widgets

CONFIG += c++17

TARGET   = CineMax
TEMPLATE = app

INCLUDEPATH += include

SOURCES += \
    src/main.cpp \
    src/CinemaSystem.cpp \
    src/LoginWindow.cpp \
    src/MainWindow.cpp

HEADERS += \
    include/CinemaSystem.h \
    include/LoginWindow.h \
    include/MainWindow.h

# Disable deprecated warnings
DEFINES += QT_DEPRECATED_WARNINGS

# Windows: set app icon and no console window
win32 {
    RC_ICONS =
    CONFIG   += windows
}

# macOS bundle
macx {
    QMAKE_INFO_PLIST = Info.plist
}
