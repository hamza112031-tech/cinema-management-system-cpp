#include "CinemaSystem.h"

Cinema::Cinema() {
    movies.append(Movie("Avengers: Final Hour", "Foreign", "Action",  150));
    movies.append(Movie("El Hareefa",           "Egyptian","Comedy",  120));
    movies.append(Movie("Titanic",              "Foreign", "Romance", 120));
    movies.append(Movie("Abdo Mota",            "Egyptian","Drama",   100));

    movies[0].addShowtime("7:00 PM"); movies[0].addShowtime("9:00 PM"); movies[0].addShowtime("11:00 PM");
    movies[1].addShowtime("4:00 PM"); movies[1].addShowtime("6:00 PM"); movies[1].addShowtime("8:00 PM");
    movies[2].addShowtime("5:00 PM"); movies[2].addShowtime("9:00 PM");
    movies[3].addShowtime("3:00 PM"); movies[3].addShowtime("7:00 PM");

    halls.append(Hall("Hall 1", "VIP",    "3D", 80));
    halls.append(Hall("Hall 2", "Normal", "2D", 150));
    halls.append(Hall("Hall 3", "VIP",    "VR", 40));
    halls.append(Hall("Hall 4", "Normal", "2D", 120));

    employees.append(Employee("Ali Hassan",    "Manager",   700));
    employees.append(Employee("Sara Ramzi",    "Cashier",   500));
    employees.append(Employee("Mohamed Kamal", "Technician",500));
    employees.append(Employee("Nour Fathy",    "Snack Bar", 400));

    employees[0].daysWorked = 22;
    employees[1].daysWorked = 20;
    employees[2].daysWorked = 18;
    employees[3].daysWorked = 15;

    finance.ticketRevenue  = 26112;
    finance.snackRevenue   = 7680;
    finance.parkingRevenue = 4608;
}

Movie* Cinema::findMovie(const QString& name) {
    for (auto& m : movies)
        if (m.name == name) return &m;
    return nullptr;
}

Employee* Cinema::findEmployee(const QString& name) {
    for (auto& e : employees)
        if (e.name == name) return &e;
    return nullptr;
}

double Cinema::calcTicketPrice(const Movie& m, const QString& hallType, bool weekend) const {
    double p = m.price;
    if (hallType == "VIP")    p += 30;
    if (weekend)              p += 50;
    return p;
}
