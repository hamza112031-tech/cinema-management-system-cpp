#include "MainWindow.h"
#include <QApplication>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QFormLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include <QListWidget>
#include <QStackedWidget>
#include <QLineEdit>
#include <QComboBox>
#include <QSpinBox>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QHeaderView>
#include <QScrollArea>
#include <QProgressBar>
#include <QSlider>
#include <QCheckBox>
#include <QMessageBox>
#include <QGroupBox>
#include <QTextEdit>
#include <QSplitter>

// ─────────────────────── THEME ───────────────────────
static const QString BG       = "#0a0d14";
static const QString SURFACE  = "#111520";
static const QString CARD     = "#171d2e";
static const QString BORDER   = "#252d42";
static const QString ACCENT   = "#e8a020";
static const QString TEAL     = "#1d9e75";
static const QString PURPLE   = "#7c5cbf";
static const QString INFO     = "#378add";
static const QString MUTED    = "#7a8499";
static const QString TEXT     = "#e8ecf4";
static const QString RED      = "#c0392b";

static QString inputStyle() {
    return QString(
        "QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {"
        "  background:%1; border:1px solid %2;"
        "  border-radius:7px; padding:8px 12px;"
        "  color:%3; font-size:13px;"
        "}"
        "QLineEdit:focus, QComboBox:focus, QSpinBox:focus {"
        "  border:1px solid %4;"
        "}"
        "QComboBox::drop-down { border:none; width:24px; }"
        "QComboBox QAbstractItemView {"
        "  background:%1; color:%3; border:1px solid %2;"
        "  selection-background-color:%2;"
        "}"
        "QSpinBox::up-button, QSpinBox::down-button {"
        "  background:%2; border:none; border-radius:3px;"
        "}"
    ).arg(CARD, BORDER, TEXT, ACCENT);
}

static QString tableStyle() {
    return QString(
        "QTableWidget {"
        "  background:%1; border:1px solid %2;"
        "  border-radius:8px; gridline-color:%2;"
        "  color:%3; font-size:12px;"
        "}"
        "QTableWidget::item { padding:8px 12px; border-bottom:1px solid %2; }"
        "QTableWidget::item:selected { background:%4; color:%3; }"
        "QHeaderView::section {"
        "  background:%5; color:%6; font-size:11px;"
        "  font-weight:bold; padding:8px 12px;"
        "  border:none; border-bottom:1px solid %2;"
        "  text-transform:uppercase; letter-spacing:1px;"
        "}"
        "QScrollBar:vertical {"
        "  background:%1; width:6px; border-radius:3px;"
        "}"
        "QScrollBar::handle:vertical {"
        "  background:%2; border-radius:3px;"
        "}"
    ).arg(CARD, BORDER, TEXT, SURFACE, SURFACE, MUTED);
}

// ─────────────────────── HELPERS ───────────────────────
QFrame* MainWindow::card(QWidget* parent) {
    QFrame* f = new QFrame(parent);
    f->setStyleSheet(QString(
        "QFrame { background:%1; border:1px solid %2; border-radius:10px; }"
    ).arg(CARD, BORDER));
    return f;
}

QLabel* MainWindow::sectionTitle(const QString& text) {
    QLabel* l = new QLabel(text);
    l->setStyleSheet(QString(
        "font-size:14px; font-weight:bold; color:%1;"
        "background:transparent; border:none; padding:0 0 4px 0;"
    ).arg(TEXT));
    return l;
}

QPushButton* MainWindow::primaryBtn(const QString& text) {
    QPushButton* b = new QPushButton(text);
    b->setCursor(Qt::PointingHandCursor);
    b->setFixedHeight(40);
    b->setStyleSheet(QString(
        "QPushButton {"
        "  background:%1; color:#000; border:none;"
        "  border-radius:8px; font-size:13px; font-weight:bold;"
        "}"
        "QPushButton:hover { background:#d4911c; }"
        "QPushButton:pressed { background:#bf8218; }"
    ).arg(ACCENT));
    return b;
}

QWidget* MainWindow::statCard(const QString& label, const QString& value, const QString& color) {
    QFrame* f = card();
    f->setMinimumHeight(90);
    QVBoxLayout* v = new QVBoxLayout(f);
    v->setContentsMargins(16, 14, 16, 14);
    QLabel* lbl = new QLabel(label);
    lbl->setStyleSheet(QString("color:%1; font-size:11px; background:transparent; border:none;").arg(MUTED));
    QLabel* val = new QLabel(value);
    val->setStyleSheet(QString("color:%1; font-size:22px; font-weight:bold; background:transparent; border:none;").arg(color));
    v->addWidget(lbl);
    v->addWidget(val);
    v->addStretch();
    return f;
}

// ─────────────────────── CONSTRUCTOR ───────────────────────
MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent) {
    setWindowTitle("CineMax — Management System");
    setMinimumSize(1100, 680);
    applyTheme();

    QWidget* central = new QWidget(this);
    setCentralWidget(central);

    QHBoxLayout* root = new QHBoxLayout(central);
    root->setContentsMargins(0, 0, 0, 0);
    root->setSpacing(0);

    setupSidebar();
    root->addWidget(sidebar);

    // Right side: topbar + pages
    QWidget* rightSide = new QWidget();
    QVBoxLayout* rightLay = new QVBoxLayout(rightSide);
    rightLay->setContentsMargins(0, 0, 0, 0);
    rightLay->setSpacing(0);

    setupTopBar();
    rightLay->addWidget(findChild<QWidget*>("topbar"));

    stack = new QStackedWidget();
    stack->setStyleSheet(QString("background:%1;").arg(BG));
    stack->addWidget(makeDashboardPage());  // 0
    stack->addWidget(makeMoviesPage());     // 1
    stack->addWidget(makeHallsPage());      // 2
    stack->addWidget(makeTicketsPage());    // 3
    stack->addWidget(makeEmployeesPage());  // 4
    stack->addWidget(makeFinancePage());    // 5
    stack->addWidget(makeSnackPage());      // 6
    stack->addWidget(makeParkingPage());    // 7
    rightLay->addWidget(stack);

    root->addWidget(rightSide);
}

void MainWindow::applyTheme() {
    setStyleSheet(QString(
        "QMainWindow, QWidget { background:%1; color:%2; font-family:'Segoe UI',Arial,sans-serif; }"
        "QScrollArea { border:none; background:transparent; }"
        "QScrollArea > QWidget > QWidget { background:transparent; }"
    ).arg(BG, TEXT));
}

// ─────────────────────── SIDEBAR ───────────────────────
void MainWindow::setupSidebar() {
    sidebar = new QWidget();
    sidebar->setFixedWidth(210);
    sidebar->setStyleSheet(QString(
        "QWidget#sidebar { background:%1; border-right:1px solid %2; }"
    ).arg(SURFACE, BORDER));
    sidebar->setObjectName("sidebar");

    QVBoxLayout* lay = new QVBoxLayout(sidebar);
    lay->setContentsMargins(0, 0, 0, 0);
    lay->setSpacing(0);

    // Logo
    QWidget* logoArea = new QWidget();
    logoArea->setStyleSheet(QString("background:%1; border-bottom:1px solid %2;").arg(SURFACE, BORDER));
    logoArea->setFixedHeight(62);
    QHBoxLayout* logoLay = new QHBoxLayout(logoArea);
    logoLay->setContentsMargins(16, 12, 16, 12);
    QLabel* logoIcon = new QLabel("🎬");
    logoIcon->setStyleSheet("font-size:22px; background:transparent;");
    QWidget* logoText = new QWidget();
    QVBoxLayout* ltLay = new QVBoxLayout(logoText);
    ltLay->setContentsMargins(0,0,0,0); ltLay->setSpacing(0);
    QLabel* name = new QLabel("CineMax");
    name->setStyleSheet(QString("font-size:14px; font-weight:bold; color:%1; background:transparent;").arg(TEXT));
    QLabel* sub = new QLabel("MANAGEMENT");
    sub->setStyleSheet(QString("font-size:9px; color:%1; letter-spacing:1px; background:transparent;").arg(ACCENT));
    ltLay->addWidget(name); ltLay->addWidget(sub);
    logoLay->addWidget(logoIcon); logoLay->addWidget(logoText);
    lay->addWidget(logoArea);

    // Nav items
    struct NavItem { QString emoji; QString label; int page; };
    QVector<NavItem> items = {
        {"📊", "Dashboard",    0},
        {"🎬", "Movies",       1},
        {"🏛️",  "Halls",        2},
        {"🎫", "Tickets",      3},
        {"👥", "Employees",    4},
        {"💰", "Finance",      5},
        {"🍿", "Snack Bar",    6},
        {"🚗", "Parking",      7},
    };

    QWidget* navArea = new QWidget();
    navArea->setStyleSheet("background:transparent;");
    QVBoxLayout* navLay = new QVBoxLayout(navArea);
    navLay->setContentsMargins(10, 10, 10, 10);
    navLay->setSpacing(2);

    QLabel* overviewLbl = new QLabel("OVERVIEW");
    overviewLbl->setStyleSheet(QString("color:%1; font-size:9px; letter-spacing:1px; padding:4px 8px; background:transparent;").arg(MUTED));
    navLay->addWidget(overviewLbl);

    for (int i = 0; i < items.size(); i++) {
        if (i == 1) {
            QLabel* modLbl = new QLabel("MODULES");
            modLbl->setStyleSheet(overviewLbl->styleSheet());
            navLay->addWidget(modLbl);
        }
        QPushButton* btn = new QPushButton(items[i].emoji + "  " + items[i].label);
        btn->setCursor(Qt::PointingHandCursor);
        btn->setFixedHeight(38);
        btn->setCheckable(true);
        btn->setChecked(i == 0);
        btn->setProperty("page", items[i].page);
        btn->setStyleSheet(QString(
            "QPushButton {"
            "  text-align:left; padding:0 12px;"
            "  background:transparent; border:none;"
            "  border-radius:8px; color:%1; font-size:13px;"
            "}"
            "QPushButton:hover { background:rgba(255,255,255,0.05); color:%2; }"
            "QPushButton:checked {"
            "  background:rgba(232,160,32,0.12);"
            "  color:%3; font-weight:bold;"
            "  border-left:3px solid %3;"
            "}"
        ).arg(MUTED, TEXT, ACCENT));
        connect(btn, &QPushButton::clicked, this, [this, btn, i]() {
            // uncheck all
            for (auto* b : sidebar->findChildren<QPushButton*>())
                b->setChecked(false);
            btn->setChecked(true);
            onNavClicked(items[i].page);
        });
        navLay->addWidget(btn);
    }
    navLay->addStretch();
    lay->addWidget(navArea);

    // Bottom bar
    QWidget* bottomBar = new QWidget();
    bottomBar->setFixedHeight(50);
    bottomBar->setStyleSheet(QString("background:%1; border-top:1px solid %2;").arg(SURFACE, BORDER));
    QHBoxLayout* bbLay = new QHBoxLayout(bottomBar);
    bbLay->setContentsMargins(12, 8, 12, 8);
    QLabel* version = new QLabel("v1.0  •  OOP Project");
    version->setStyleSheet(QString("color:%1; font-size:10px; background:transparent;").arg(MUTED));
    bbLay->addWidget(version);
    lay->addWidget(bottomBar);
}

void MainWindow::setupTopBar() {
    QWidget* topbar = new QWidget();
    topbar->setObjectName("topbar");
    topbar->setFixedHeight(52);
    topbar->setStyleSheet(QString(
        "background:%1; border-bottom:1px solid %2;"
    ).arg(SURFACE, BORDER));

    QHBoxLayout* lay = new QHBoxLayout(topbar);
    lay->setContentsMargins(20, 0, 20, 0);

    pageTitle = new QLabel("Dashboard");
    pageTitle->setStyleSheet(QString(
        "font-size:16px; font-weight:bold; color:%1; background:transparent;"
    ).arg(TEXT));

    QLabel* badge = new QLabel("CineMax — Cinema Management System");
    badge->setStyleSheet(QString(
        "background:rgba(232,160,32,0.12); color:%1;"
        "padding:3px 12px; border-radius:12px; font-size:11px; border:none;"
    ).arg(ACCENT));

    lay->addWidget(pageTitle);
    lay->addStretch();
    lay->addWidget(badge);
}

void MainWindow::onNavClicked(int page) {
    static QStringList titles = {
        "Dashboard", "Movie Management", "Halls & Screens",
        "Ticket Booking", "Employee Management", "Finance & Revenue",
        "Snack Bar", "Parking System"
    };
    stack->setCurrentIndex(page);
    if (page < titles.size()) pageTitle->setText(titles[page]);
}

// ═══════════════════════════════════════════════════════
//  PAGE 0 — DASHBOARD
// ═══════════════════════════════════════════════════════
QWidget* MainWindow::makeDashboardPage() {
    QScrollArea* scroll = new QScrollArea();
    scroll->setWidgetResizable(true);
    QWidget* page = new QWidget();
    QVBoxLayout* lay = new QVBoxLayout(page);
    lay->setContentsMargins(20, 20, 20, 20);
    lay->setSpacing(14);

    // Stat cards
    QHBoxLayout* statsRow = new QHBoxLayout();
    statsRow->setSpacing(12);
    statsRow->addWidget(statCard("🎫  Tickets Sold",  "248",    ACCENT));
    statsRow->addWidget(statCard("💰  Revenue (EGP)", "38,400", TEAL));
    statsRow->addWidget(statCard("🎬  Active Movies",  "4",     INFO));
    statsRow->addWidget(statCard("👥  Employees",      "14",    PURPLE));
    lay->addLayout(statsRow);

    // Now showing + Revenue breakdown
    QHBoxLayout* midRow = new QHBoxLayout();
    midRow->setSpacing(12);

    // Movies card
    QFrame* movCard = card();
    QVBoxLayout* mcLay = new QVBoxLayout(movCard);
    mcLay->setContentsMargins(16, 14, 16, 14);
    mcLay->addWidget(sectionTitle("🎬  Now Showing"));
    QTableWidget* movTable = new QTableWidget(4, 3);
    movTable->setStyleSheet(tableStyle());
    movTable->setHorizontalHeaderLabels({"Movie", "Genre", "Showtimes"});
    movTable->horizontalHeader()->setStretchLastSection(true);
    movTable->verticalHeader()->setVisible(false);
    movTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    movTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    movTable->setFixedHeight(180);
    QStringList mnames = {"Avengers: Final Hour","El Hareefa","Titanic","Abdo Mota"};
    QStringList genres = {"Action","Comedy","Romance","Drama"};
    QStringList times  = {"7PM 9PM 11PM","4PM 6PM 8PM","5PM 9PM","3PM 7PM"};
    for (int r = 0; r < 4; r++) {
        movTable->setItem(r,0,new QTableWidgetItem(mnames[r]));
        movTable->setItem(r,1,new QTableWidgetItem(genres[r]));
        movTable->setItem(r,2,new QTableWidgetItem(times[r]));
    }
    mcLay->addWidget(movTable);
    midRow->addWidget(movCard, 3);

    // Revenue breakdown card
    QFrame* revCard = card();
    QVBoxLayout* rcLay = new QVBoxLayout(revCard);
    rcLay->setContentsMargins(16, 14, 16, 14);
    rcLay->addWidget(sectionTitle("📊  Revenue Breakdown"));
    struct BarData { QString label; int pct; QString color; };
    QVector<BarData> bars = {{"Tickets", 68, ACCENT}, {"Snack Bar", 20, TEAL}, {"Parking", 12, PURPLE}};
    for (auto& b : bars) {
        QHBoxLayout* bRow = new QHBoxLayout();
        QLabel* lbl = new QLabel(b.label);
        lbl->setFixedWidth(72);
        lbl->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
        QProgressBar* pb = new QProgressBar();
        pb->setRange(0,100); pb->setValue(b.pct);
        pb->setTextVisible(false); pb->setFixedHeight(8);
        pb->setStyleSheet(QString(
            "QProgressBar { background:%1; border-radius:4px; border:none; }"
            "QProgressBar::chunk { background:%2; border-radius:4px; }"
        ).arg(BORDER, b.color));
        QLabel* pct = new QLabel(QString("%1%").arg(b.pct));
        pct->setFixedWidth(36);
        pct->setAlignment(Qt::AlignRight|Qt::AlignVCenter);
        pct->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
        bRow->addWidget(lbl); bRow->addWidget(pb); bRow->addWidget(pct);
        rcLay->addLayout(bRow);
        rcLay->addSpacing(6);
    }
    rcLay->addStretch();

    // Recent Activity
    rcLay->addWidget(sectionTitle("⚡  Recent Activity"));
    QStringList acts = {
        "✅  Ticket booked — Avengers VIP Seat 12",
        "🍿  Snack order — 2×Popcorn 1×Drink",
        "👤  New employee added — Sara (Cashier)"
    };
    for (auto& a : acts) {
        QLabel* al = new QLabel(a);
        al->setStyleSheet(QString("color:%1; font-size:12px; background:transparent; padding:4px 0;").arg(MUTED));
        rcLay->addWidget(al);
    }
    midRow->addWidget(revCard, 2);
    lay->addLayout(midRow);

    // Hall status row
    QFrame* hallCard = card();
    QVBoxLayout* hlLay = new QVBoxLayout(hallCard);
    hlLay->setContentsMargins(16, 14, 16, 14);
    hlLay->addWidget(sectionTitle("🏛️  Hall Status"));
    QHBoxLayout* hallRow = new QHBoxLayout();
    struct HallInfo { QString name; QString type; QString screen; int cap; QString status; QString scolor; };
    QVector<HallInfo> halls_ = {
        {"Hall 1","VIP","3D",80,"Full",RED},
        {"Hall 2","Normal","2D",150,"Open",TEAL},
        {"Hall 3","VIP","VR",40,"VIP",PURPLE},
        {"Hall 4","Normal","2D",120,"Open",TEAL}
    };
    for (auto& h : halls_) {
        QFrame* hc = new QFrame();
        hc->setStyleSheet(QString("background:%1; border:1px solid %2; border-radius:8px;").arg(SURFACE, BORDER));
        QVBoxLayout* hcl = new QVBoxLayout(hc);
        hcl->setContentsMargins(12,10,12,10);
        QLabel* hn = new QLabel(h.name);
        hn->setStyleSheet(QString("font-size:15px; font-weight:bold; color:%1; background:transparent;").arg(ACCENT));
        QLabel* ht = new QLabel(h.type + " · " + h.screen);
        ht->setStyleSheet(QString("font-size:11px; color:%1; background:transparent;").arg(MUTED));
        QLabel* hcap = new QLabel(QString("👥 %1 seats").arg(h.cap));
        hcap->setStyleSheet(QString("font-size:11px; color:%1; background:transparent;").arg(MUTED));
        QLabel* hstat = new QLabel(h.status);
        hstat->setStyleSheet(QString(
            "font-size:11px; color:%1; background:rgba(0,0,0,0.2);"
            "border-radius:10px; padding:2px 10px; border:none;"
        ).arg(h.scolor));
        hcl->addWidget(hn); hcl->addWidget(ht); hcl->addWidget(hcap); hcl->addWidget(hstat);
        hallRow->addWidget(hc);
    }
    hlLay->addLayout(hallRow);
    lay->addWidget(hallCard);
    lay->addStretch();

    scroll->setWidget(page);
    return scroll;
}

// ═══════════════════════════════════════════════════════
//  PAGE 1 — MOVIES
// ═══════════════════════════════════════════════════════
QWidget* MainWindow::makeMoviesPage() {
    QSplitter* splitter = new QSplitter(Qt::Horizontal);
    splitter->setStyleSheet(QString("QSplitter { background:%1; } QSplitter::handle { background:%2; width:1px; }").arg(BG, BORDER));

    // Left — movie list
    QWidget* leftW = new QWidget();
    QVBoxLayout* leftLay = new QVBoxLayout(leftW);
    leftLay->setContentsMargins(20,20,10,20);
    leftLay->addWidget(sectionTitle("🎬  Movie List"));

    QTableWidget* table = new QTableWidget(0, 5);
    table->setStyleSheet(tableStyle());
    table->setHorizontalHeaderLabels({"Name","Origin","Genre","Price","Showtimes"});
    table->horizontalHeader()->setStretchLastSection(true);
    table->verticalHeader()->setVisible(false);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);

    for (auto& m : cinema.movies) {
        int r = table->rowCount(); table->insertRow(r);
        table->setItem(r,0,new QTableWidgetItem(m.name));
        table->setItem(r,1,new QTableWidgetItem(m.origin));
        table->setItem(r,2,new QTableWidgetItem(m.genre));
        table->setItem(r,3,new QTableWidgetItem(QString("%1 EGP").arg(m.price)));
        table->setItem(r,4,new QTableWidgetItem(QString("%1 shows").arg(m.showtimes.size())));
    }
    leftLay->addWidget(table);

    QPushButton* removeBtn = new QPushButton("🗑️  Remove Selected Movie");
    removeBtn->setCursor(Qt::PointingHandCursor);
    removeBtn->setFixedHeight(38);
    removeBtn->setStyleSheet(QString(
        "QPushButton { background:rgba(192,57,43,0.15); color:#e07060;"
        "border:1px solid rgba(192,57,43,0.3); border-radius:8px; font-size:13px; }"
        "QPushButton:hover { background:rgba(192,57,43,0.25); }"
    ));
    connect(removeBtn, &QPushButton::clicked, this, [=]() {
        int row = table->currentRow();
        if (row >= 0) {
            QString name = table->item(row,0)->text();
            cinema.movies.erase(
                std::remove_if(cinema.movies.begin(), cinema.movies.end(),
                               [&](const Movie& m){ return m.name == name; }),
                cinema.movies.end());
            table->removeRow(row);
            QMessageBox::information(this, "Removed", "Movie \"" + name + "\" removed successfully.");
        }
    });
    leftLay->addWidget(removeBtn);
    splitter->addWidget(leftW);

    // Right — Add movie form
    QFrame* rightW = card();
    QVBoxLayout* rightLay = new QVBoxLayout(rightW);
    rightLay->setContentsMargins(20,20,20,20);
    rightLay->addWidget(sectionTitle("➕  Add New Movie"));

    QLineEdit* nameEdit   = new QLineEdit(); nameEdit->setPlaceholderText("e.g. Spider-Man");
    QComboBox* originBox  = new QComboBox(); originBox->addItems({"Foreign","Egyptian"});
    QComboBox* genreBox   = new QComboBox(); genreBox->addItems({"Action","Comedy","Romance","Drama","Horror","Sci-Fi","Animation"});
    QSpinBox*  priceBox   = new QSpinBox(); priceBox->setRange(0,500); priceBox->setValue(120); priceBox->setSuffix(" EGP");
    QLineEdit* timesEdit  = new QLineEdit(); timesEdit->setPlaceholderText("7 PM, 9 PM, 11 PM");

    for (auto* w : QVector<QWidget*>{nameEdit,originBox,genreBox,priceBox,timesEdit})
        w->setStyleSheet(inputStyle());

    QFormLayout* form = new QFormLayout();
    form->setSpacing(10);
    auto addRow = [&](const QString& lbl, QWidget* w) {
        QLabel* l = new QLabel(lbl);
        l->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
        form->addRow(l, w);
    };
    addRow("Movie Name", nameEdit);
    addRow("Origin", originBox);
    addRow("Genre", genreBox);
    addRow("Base Price", priceBox);
    addRow("Showtimes", timesEdit);
    rightLay->addLayout(form);
    rightLay->addSpacing(8);

    QPushButton* addBtn = primaryBtn("➕  Add Movie");
    connect(addBtn, &QPushButton::clicked, this, [=]() {
        if (nameEdit->text().trimmed().isEmpty()) {
            QMessageBox::warning(this, "Error", "Please enter a movie name.");
            return;
        }
        Movie m(nameEdit->text().trimmed(), originBox->currentText(),
                genreBox->currentText(), priceBox->value());
        for (auto& t : timesEdit->text().split(","))
            if (!t.trimmed().isEmpty()) m.addShowtime(t.trimmed());
        cinema.movies.append(m);
        int r = table->rowCount(); table->insertRow(r);
        table->setItem(r,0,new QTableWidgetItem(m.name));
        table->setItem(r,1,new QTableWidgetItem(m.origin));
        table->setItem(r,2,new QTableWidgetItem(m.genre));
        table->setItem(r,3,new QTableWidgetItem(QString("%1 EGP").arg(m.price)));
        table->setItem(r,4,new QTableWidgetItem(QString("%1 shows").arg(m.showtimes.size())));
        nameEdit->clear(); timesEdit->clear();
        QMessageBox::information(this, "Success", "Movie added successfully!");
    });
    rightLay->addWidget(addBtn);
    rightLay->addStretch();
    splitter->addWidget(rightW);
    splitter->setSizes({620, 380});

    QWidget* wrap = new QWidget();
    QVBoxLayout* wl = new QVBoxLayout(wrap);
    wl->setContentsMargins(0,0,0,0);
    wl->addWidget(splitter);
    return wrap;
}

// ═══════════════════════════════════════════════════════
//  PAGE 2 — HALLS
// ═══════════════════════════════════════════════════════
QWidget* MainWindow::makeHallsPage() {
    QWidget* page = new QWidget();
    QVBoxLayout* lay = new QVBoxLayout(page);
    lay->setContentsMargins(20,20,20,20); lay->setSpacing(14);

    QHBoxLayout* row = new QHBoxLayout(); row->setSpacing(12);

    // Hall list
    QFrame* listCard = card();
    QVBoxLayout* llLay = new QVBoxLayout(listCard);
    llLay->setContentsMargins(16,14,16,14);
    llLay->addWidget(sectionTitle("🏛️  Halls Overview"));
    QTableWidget* ht = new QTableWidget(0,4);
    ht->setStyleSheet(tableStyle());
    ht->setHorizontalHeaderLabels({"Hall","Type","Screen","Capacity"});
    ht->horizontalHeader()->setStretchLastSection(true);
    ht->verticalHeader()->setVisible(false);
    ht->setEditTriggers(QAbstractItemView::NoEditTriggers);
    for (auto& h : cinema.halls) {
        int r = ht->rowCount(); ht->insertRow(r);
        ht->setItem(r,0,new QTableWidgetItem(h.name));
        ht->setItem(r,1,new QTableWidgetItem(h.type));
        ht->setItem(r,2,new QTableWidgetItem(h.screen));
        ht->setItem(r,3,new QTableWidgetItem(QString("%1 seats").arg(h.capacity)));
    }
    llLay->addWidget(ht);
    row->addWidget(listCard, 3);

    // Add hall form
    QFrame* formCard = card();
    QVBoxLayout* fcLay = new QVBoxLayout(formCard);
    fcLay->setContentsMargins(16,14,16,14);
    fcLay->addWidget(sectionTitle("➕  Add New Hall"));
    QLineEdit* hName = new QLineEdit(); hName->setPlaceholderText("Hall 5");
    QComboBox* hType = new QComboBox(); hType->addItems({"Normal","VIP"});
    QComboBox* hScreen = new QComboBox(); hScreen->addItems({"2D","3D","VR"});
    QSpinBox*  hCap  = new QSpinBox(); hCap->setRange(10,500); hCap->setValue(100);
    for (auto* w : QVector<QWidget*>{hName,hType,hScreen,hCap})
        w->setStyleSheet(inputStyle());
    QFormLayout* hForm = new QFormLayout(); hForm->setSpacing(10);
    auto addRow2 = [&](const QString& lbl, QWidget* w) {
        QLabel* l = new QLabel(lbl);
        l->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
        hForm->addRow(l, w);
    };
    addRow2("Hall Name", hName);
    addRow2("Type", hType);
    addRow2("Screen", hScreen);
    addRow2("Capacity", hCap);
    fcLay->addLayout(hForm);
    fcLay->addSpacing(8);
    QPushButton* addHallBtn = primaryBtn("➕  Add Hall");
    connect(addHallBtn, &QPushButton::clicked, this, [=]() {
        if (hName->text().trimmed().isEmpty()) return;
        Hall h(hName->text().trimmed(), hType->currentText(), hScreen->currentText(), hCap->value());
        cinema.halls.append(h);
        int r = ht->rowCount(); ht->insertRow(r);
        ht->setItem(r,0,new QTableWidgetItem(h.name));
        ht->setItem(r,1,new QTableWidgetItem(h.type));
        ht->setItem(r,2,new QTableWidgetItem(h.screen));
        ht->setItem(r,3,new QTableWidgetItem(QString("%1 seats").arg(h.capacity)));
        hName->clear();
        QMessageBox::information(this, "Success", "Hall added successfully!");
    });
    fcLay->addWidget(addHallBtn);
    fcLay->addStretch();
    row->addWidget(formCard, 2);
    lay->addLayout(row);

    // Screen types info
    QFrame* scCard = card();
    QVBoxLayout* scLay = new QVBoxLayout(scCard);
    scLay->setContentsMargins(16,14,16,14);
    scLay->addWidget(sectionTitle("🖥️  Screen Types"));
    QHBoxLayout* scRow = new QHBoxLayout();
    struct ScType { QString emoji; QString name; QString desc; QString extra; QString color; };
    QVector<ScType> scts = {
        {"📺","2D Screen","Standard definition","No extra charge",MUTED},
        {"🎭","3D Screen","Immersive 3D experience","+40 EGP per ticket",ACCENT},
        {"🥽","VR Screen","Full virtual reality","+80 EGP per ticket",PURPLE}
    };
    for (auto& s : scts) {
        QFrame* sf = new QFrame();
        sf->setStyleSheet(QString("background:%1; border:1px solid %2; border-radius:8px;").arg(SURFACE, BORDER));
        QVBoxLayout* sfl = new QVBoxLayout(sf);
        sfl->setContentsMargins(14,12,14,12); sfl->setAlignment(Qt::AlignCenter);
        QLabel* si = new QLabel(s.emoji);
        si->setStyleSheet("font-size:28px; background:transparent;");
        si->setAlignment(Qt::AlignCenter);
        QLabel* sn = new QLabel(s.name);
        sn->setStyleSheet(QString("font-size:13px; font-weight:bold; color:%1; background:transparent;").arg(TEXT));
        sn->setAlignment(Qt::AlignCenter);
        QLabel* sd = new QLabel(s.desc);
        sd->setStyleSheet(QString("font-size:11px; color:%1; background:transparent;").arg(MUTED));
        sd->setAlignment(Qt::AlignCenter);
        QLabel* se = new QLabel(s.extra);
        se->setStyleSheet(QString("font-size:11px; color:%1; background:transparent; font-weight:bold;").arg(s.color));
        se->setAlignment(Qt::AlignCenter);
        sfl->addWidget(si); sfl->addWidget(sn); sfl->addWidget(sd); sfl->addWidget(se);
        scRow->addWidget(sf);
    }
    scLay->addLayout(scRow);
    lay->addWidget(scCard);
    lay->addStretch();
    return page;
}

// ═══════════════════════════════════════════════════════
//  PAGE 3 — TICKETS
// ═══════════════════════════════════════════════════════
QWidget* MainWindow::makeTicketsPage() {
    QWidget* page = new QWidget();
    QHBoxLayout* lay = new QHBoxLayout(page);
    lay->setContentsMargins(20,20,20,20); lay->setSpacing(14);

    // Booking form
    QFrame* formCard = card();
    QVBoxLayout* fcLay = new QVBoxLayout(formCard);
    fcLay->setContentsMargins(20,18,20,18);
    fcLay->addWidget(sectionTitle("🎫  Book a Ticket"));
    fcLay->addSpacing(6);

    QComboBox* movieBox = new QComboBox();
    for (auto& m : cinema.movies) movieBox->addItem(m.name);
    QComboBox* timeBox  = new QComboBox();
    timeBox->addItems({"7:00 PM","9:00 PM","11:00 PM"});
    QComboBox* hallBox  = new QComboBox();
    hallBox->addItems({"Normal","VIP (+30 EGP)"});
    QComboBox* dayBox   = new QComboBox();
    dayBox->addItems({"Weekday","Weekend (+50 EGP)"});
    QSpinBox*  seatBox  = new QSpinBox();
    seatBox->setRange(1,150); seatBox->setValue(1);

    for (auto* w : QVector<QWidget*>{movieBox,timeBox,hallBox,dayBox,seatBox})
        w->setStyleSheet(inputStyle());

    // Price display
    QFrame* priceBox_ = new QFrame();
    priceBox_->setStyleSheet(QString(
        "background:rgba(232,160,32,0.08); border:1px solid rgba(232,160,32,0.25);"
        "border-radius:10px;"
    ));
    QVBoxLayout* pbLay = new QVBoxLayout(priceBox_);
    pbLay->setContentsMargins(14,12,14,12);
    QLabel* baseLabel   = new QLabel("Base Price:  150 EGP");
    QLabel* extraLabel  = new QLabel("Surcharges:  +0 EGP");
    QFrame* divLine = new QFrame(); divLine->setFrameShape(QFrame::HLine);
    divLine->setStyleSheet(QString("color:%1;").arg(BORDER));
    QLabel* totalLabel  = new QLabel("Total:  150 EGP");
    for (auto* l : {baseLabel, extraLabel})
        l->setStyleSheet(QString("color:%1; font-size:12px; background:transparent; border:none;").arg(MUTED));
    totalLabel->setStyleSheet(QString("color:%1; font-size:16px; font-weight:bold; background:transparent; border:none;").arg(ACCENT));
    pbLay->addWidget(baseLabel); pbLay->addWidget(extraLabel);
    pbLay->addWidget(divLine); pbLay->addWidget(totalLabel);

    auto calcPrice = [=]() {
        double base = 150;
        Movie* m = cinema.findMovie(movieBox->currentText());
        if (m) base = m->price;
        double extra = 0;
        if (hallBox->currentIndex() == 1) extra += 30;
        if (dayBox->currentIndex() == 1)  extra += 50;
        baseLabel->setText(QString("Base Price:  %1 EGP").arg(base));
        extraLabel->setText(QString("Surcharges:  +%1 EGP").arg(extra));
        totalLabel->setText(QString("Total:  %1 EGP").arg(base + extra));
    };
    connect(movieBox, QOverload<int>::of(&QComboBox::currentIndexChanged), this, calcPrice);
    connect(hallBox,  QOverload<int>::of(&QComboBox::currentIndexChanged), this, calcPrice);
    connect(dayBox,   QOverload<int>::of(&QComboBox::currentIndexChanged), this, calcPrice);

    QFormLayout* form = new QFormLayout(); form->setSpacing(10);
    auto addRow = [&](const QString& lbl, QWidget* w) {
        QLabel* l = new QLabel(lbl);
        l->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
        form->addRow(l, w);
    };
    addRow("Select Movie", movieBox);
    addRow("Showtime", timeBox);
    addRow("Hall Type", hallBox);
    addRow("Day Type", dayBox);
    addRow("Seat Number", seatBox);
    fcLay->addLayout(form);
    fcLay->addSpacing(10);
    fcLay->addWidget(priceBox_);
    fcLay->addSpacing(10);
    fcLay->addWidget(primaryBtn("✅  Confirm Booking"));
    fcLay->addStretch();
    lay->addWidget(formCard, 2);

    // Seat map
    QFrame* seatCard = card();
    QVBoxLayout* scLay = new QVBoxLayout(seatCard);
    scLay->setContentsMargins(16,14,16,14);
    scLay->addWidget(sectionTitle("💺  Seat Map — Hall 1"));

    // Legend
    QHBoxLayout* legendRow = new QHBoxLayout();
    struct Legend { QString label; QString color; };
    QVector<Legend> leg = {{"Available","#252d42"},{"Taken","rgba(192,57,43,0.5)"},{"Selected",ACCENT},{"VIP",PURPLE}};
    for (auto& l : leg) {
        QFrame* dot = new QFrame(); dot->setFixedSize(12,12);
        dot->setStyleSheet(QString("background:%1; border-radius:3px;").arg(l.color));
        QLabel* lbl = new QLabel(l.label);
        lbl->setStyleSheet(QString("color:%1; font-size:11px; background:transparent;").arg(MUTED));
        legendRow->addWidget(dot); legendRow->addWidget(lbl); legendRow->addSpacing(8);
    }
    legendRow->addStretch();
    scLay->addLayout(legendRow);

    QLabel* screenBar = new QLabel("◀─────────  SCREEN  ─────────▶");
    screenBar->setAlignment(Qt::AlignCenter);
    screenBar->setStyleSheet(QString(
        "background:rgba(232,160,32,0.15); color:%1; border-radius:4px;"
        "padding:4px; font-size:11px; border:none;"
    ).arg(ACCENT));
    scLay->addWidget(screenBar);

    QGridLayout* seatGrid = new QGridLayout();
    seatGrid->setSpacing(4);
    QSet<int> taken = {2,5,7,11,14,17,22,25,28,31,35,38,42,45};
    for (int i = 1; i <= 50; i++) {
        int row = (i-1)/10, col = (i-1)%10;
        QPushButton* sb = new QPushButton(QString::number(i));
        sb->setFixedSize(34,28);
        sb->setCheckable(true);
        bool isVip = (row == 0);
        bool isTaken = taken.contains(i);
        QString style;
        if (isTaken) {
            style = "QPushButton { background:rgba(192,57,43,0.5); color:#fff; border:1px solid rgba(192,57,43,0.3); border-radius:4px; font-size:10px; }";
            sb->setEnabled(false);
        } else if (isVip) {
            style = QString(
                "QPushButton { background:rgba(124,92,191,0.35); color:%1; border:1px solid rgba(124,92,191,0.4); border-radius:4px; font-size:10px; }"
                "QPushButton:checked { background:%2; color:#000; }"
            ).arg(TEXT, ACCENT);
        } else {
            style = QString(
                "QPushButton { background:#252d42; color:%1; border:1px solid #2e3750; border-radius:4px; font-size:10px; }"
                "QPushButton:checked { background:%2; color:#000; }"
            ).arg(TEXT, ACCENT);
        }
        sb->setStyleSheet(style);
        seatGrid->addWidget(sb, row, col);
    }
    scLay->addLayout(seatGrid);
    scLay->addStretch();
    lay->addWidget(seatCard, 3);

    return page;
}

// ═══════════════════════════════════════════════════════
//  PAGE 4 — EMPLOYEES
// ═══════════════════════════════════════════════════════
QWidget* MainWindow::makeEmployeesPage() {
    QSplitter* spl = new QSplitter(Qt::Horizontal);
    spl->setStyleSheet(QString("QSplitter { background:%1; } QSplitter::handle { background:%2; }").arg(BG, BORDER));

    // Left — list
    QWidget* left = new QWidget();
    QVBoxLayout* ll = new QVBoxLayout(left);
    ll->setContentsMargins(20,20,10,20);
    ll->addWidget(sectionTitle("👥  Staff List"));
    QTableWidget* et = new QTableWidget(0,5);
    et->setStyleSheet(tableStyle());
    et->setHorizontalHeaderLabels({"Name","Position","Daily Rate","Days","Total Salary"});
    et->horizontalHeader()->setStretchLastSection(true);
    et->verticalHeader()->setVisible(false);
    et->setEditTriggers(QAbstractItemView::NoEditTriggers);
    et->setSelectionBehavior(QAbstractItemView::SelectRows);
    for (auto& e : cinema.employees) {
        int r = et->rowCount(); et->insertRow(r);
        et->setItem(r,0,new QTableWidgetItem(e.name));
        et->setItem(r,1,new QTableWidgetItem(e.position));
        et->setItem(r,2,new QTableWidgetItem(QString("%1 EGP").arg(e.dailyRate)));
        et->setItem(r,3,new QTableWidgetItem(QString("%1 days").arg(e.daysWorked)));
        auto* salItem = new QTableWidgetItem(QString("%1 EGP").arg(e.salary()));
        salItem->setForeground(QColor(TEAL));
        et->setItem(r,4,salItem);
    }
    ll->addWidget(et);
    spl->addWidget(left);

    // Right — Add + Salary Calc
    QWidget* right = new QWidget();
    QVBoxLayout* rl = new QVBoxLayout(right);
    rl->setContentsMargins(10,20,20,20); rl->setSpacing(12);

    // Add employee
    QFrame* addCard = card();
    QVBoxLayout* acl = new QVBoxLayout(addCard);
    acl->setContentsMargins(16,14,16,14);
    acl->addWidget(sectionTitle("➕  Add Employee"));
    QLineEdit* eName = new QLineEdit(); eName->setPlaceholderText("Full Name");
    QComboBox* ePos  = new QComboBox(); ePos->addItems({"Manager","Cashier","Technician","Snack Bar","Security","Cleaner"});
    QSpinBox*  eRate = new QSpinBox(); eRate->setRange(100,2000); eRate->setValue(500); eRate->setSuffix(" EGP/day");
    for (auto* w : QVector<QWidget*>{eName,ePos,eRate}) w->setStyleSheet(inputStyle());
    QFormLayout* eForm = new QFormLayout(); eForm->setSpacing(8);
    auto addRow3 = [&](const QString& lbl, QWidget* w) {
        QLabel* l = new QLabel(lbl);
        l->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
        eForm->addRow(l, w);
    };
    addRow3("Full Name", eName);
    addRow3("Position", ePos);
    addRow3("Daily Rate", eRate);
    acl->addLayout(eForm);
    QPushButton* addEmpBtn = primaryBtn("➕  Add Employee");
    connect(addEmpBtn, &QPushButton::clicked, this, [=]() {
        if (eName->text().trimmed().isEmpty()) return;
        Employee e(eName->text().trimmed(), ePos->currentText(), eRate->value());
        cinema.employees.append(e);
        int r = et->rowCount(); et->insertRow(r);
        et->setItem(r,0,new QTableWidgetItem(e.name));
        et->setItem(r,1,new QTableWidgetItem(e.position));
        et->setItem(r,2,new QTableWidgetItem(QString("%1 EGP").arg(e.dailyRate)));
        et->setItem(r,3,new QTableWidgetItem("0 days"));
        et->setItem(r,4,new QTableWidgetItem("0 EGP"));
        eName->clear();
        QMessageBox::information(this, "Success", "Employee added!");
    });
    acl->addWidget(addEmpBtn);
    rl->addWidget(addCard);

    // Salary calculator
    QFrame* calcCard = card();
    QVBoxLayout* ccl = new QVBoxLayout(calcCard);
    ccl->setContentsMargins(16,14,16,14);
    ccl->addWidget(sectionTitle("🧮  Salary Calculator"));
    QComboBox* empSel = new QComboBox();
    for (auto& e : cinema.employees) empSel->addItem(e.name);
    QSpinBox* daysBox = new QSpinBox(); daysBox->setRange(0,31); daysBox->setValue(22);
    QSpinBox* rateBox2 = new QSpinBox(); rateBox2->setRange(0,5000); rateBox2->setValue(700); rateBox2->setSuffix(" EGP");
    for (auto* w : QVector<QWidget*>{empSel,daysBox,rateBox2}) w->setStyleSheet(inputStyle());
    QLabel* salResult = new QLabel("15,400 EGP");
    salResult->setAlignment(Qt::AlignCenter);
    salResult->setStyleSheet(QString(
        "font-size:26px; font-weight:bold; color:%1;"
        "background:%2; border-radius:8px; padding:12px;"
        "border:1px solid %3;"
    ).arg(TEAL, SURFACE, BORDER));
    auto updateSal = [=]() {
        double total = daysBox->value() * rateBox2->value();
        salResult->setText(QString("%1 EGP").arg(total));
    };
    connect(daysBox,  QOverload<int>::of(&QSpinBox::valueChanged), this, updateSal);
    connect(rateBox2, QOverload<int>::of(&QSpinBox::valueChanged), this, updateSal);
    QFormLayout* sForm = new QFormLayout(); sForm->setSpacing(8);
    auto addRowS = [&](const QString& lbl, QWidget* w) {
        QLabel* l = new QLabel(lbl); l->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
        sForm->addRow(l, w);
    };
    addRowS("Employee", empSel);
    addRowS("Days Worked", daysBox);
    addRowS("Daily Rate", rateBox2);
    ccl->addLayout(sForm);
    ccl->addSpacing(8);
    ccl->addWidget(salResult);
    ccl->addSpacing(6);
    ccl->addWidget(primaryBtn("💾  Save Salary"));
    rl->addWidget(calcCard);
    rl->addStretch();
    spl->addWidget(right);
    spl->setSizes({600,380});

    QWidget* wrap = new QWidget();
    QVBoxLayout* wl = new QVBoxLayout(wrap);
    wl->setContentsMargins(0,0,0,0);
    wl->addWidget(spl);
    return wrap;
}

// ═══════════════════════════════════════════════════════
//  PAGE 5 — FINANCE
// ═══════════════════════════════════════════════════════
QWidget* MainWindow::makeFinancePage() {
    QScrollArea* scroll = new QScrollArea(); scroll->setWidgetResizable(true);
    QWidget* page = new QWidget();
    QVBoxLayout* lay = new QVBoxLayout(page);
    lay->setContentsMargins(20,20,20,20); lay->setSpacing(14);

    // Big total card
    QFrame* totalCard = new QFrame();
    totalCard->setStyleSheet(QString(
        "background:qlineargradient(x1:0,y1:0,x2:1,y2:1,"
        "stop:0 rgba(232,160,32,0.15), stop:1 rgba(232,160,32,0.04));"
        "border:1px solid rgba(232,160,32,0.3); border-radius:12px;"
    ));
    QVBoxLayout* tcl = new QVBoxLayout(totalCard);
    tcl->setContentsMargins(20,18,20,18); tcl->setAlignment(Qt::AlignCenter);
    QLabel* tcLbl = new QLabel("Total Revenue This Month");
    tcLbl->setAlignment(Qt::AlignCenter);
    tcLbl->setStyleSheet(QString("color:%1; font-size:13px; background:transparent; border:none;").arg(MUTED));
    QLabel* tcVal = new QLabel("38,400 EGP");
    tcVal->setAlignment(Qt::AlignCenter);
    tcVal->setStyleSheet(QString("color:%1; font-size:32px; font-weight:bold; background:transparent; border:none;").arg(ACCENT));
    QLabel* tcNet = new QLabel("Net after 14% tax:   33,024 EGP");
    tcNet->setAlignment(Qt::AlignCenter);
    tcNet->setStyleSheet(QString("color:%1; font-size:13px; background:transparent; border:none;").arg(TEAL));
    tcl->addWidget(tcLbl); tcl->addWidget(tcVal); tcl->addWidget(tcNet);
    lay->addWidget(totalCard);

    // 3 stat cards
    QHBoxLayout* statsRow = new QHBoxLayout(); statsRow->setSpacing(12);
    statsRow->addWidget(statCard("🎫  Ticket Sales",  "26,112 EGP", ACCENT));
    statsRow->addWidget(statCard("🍿  Snack Sales",   "7,680 EGP",  TEAL));
    statsRow->addWidget(statCard("🚗  Parking",       "4,608 EGP",  PURPLE));
    lay->addLayout(statsRow);

    // Summary table
    QFrame* summCard = card();
    QVBoxLayout* scl = new QVBoxLayout(summCard);
    scl->setContentsMargins(16,14,16,14);
    scl->addWidget(sectionTitle("📋  Tax & Profit Summary"));
    QTableWidget* ft = new QTableWidget(4,2);
    ft->setStyleSheet(tableStyle());
    ft->setHorizontalHeaderLabels({"Item","Amount"});
    ft->horizontalHeader()->setStretchLastSection(true);
    ft->verticalHeader()->setVisible(false);
    ft->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ft->setFixedHeight(160);
    auto addFRow = [&](int r, const QString& item, const QString& amt, const QString& color) {
        ft->insertRow(r);
        ft->setItem(r,0,new QTableWidgetItem(item));
        auto* it = new QTableWidgetItem(amt);
        it->setForeground(QColor(color));
        ft->setItem(r,1,it);
    };
    addFRow(0,"Gross Revenue","38,400 EGP", TEXT);
    addFRow(1,"Tax (14%)",    "−5,376 EGP", RED);
    addFRow(2,"Salaries",     "−40,400 EGP",RED);
    addFRow(3,"Net Profit",   "−7,376 EGP", TEAL);
    scl->addWidget(ft);
    lay->addWidget(summCard);

    // Revenue breakdown bars
    QFrame* barCard = card();
    QVBoxLayout* bcl = new QVBoxLayout(barCard);
    bcl->setContentsMargins(16,14,16,14);
    bcl->addWidget(sectionTitle("📊  Revenue Distribution"));
    struct Bar { QString label; int pct; QString color; };
    for (auto& b : QVector<Bar>{{"Tickets",68,ACCENT},{"Snack Bar",20,TEAL},{"Parking",12,PURPLE}}) {
        QHBoxLayout* bRow = new QHBoxLayout();
        QLabel* lbl = new QLabel(b.label); lbl->setFixedWidth(80);
        lbl->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
        QProgressBar* pb = new QProgressBar(); pb->setRange(0,100); pb->setValue(b.pct);
        pb->setTextVisible(false); pb->setFixedHeight(10);
        pb->setStyleSheet(QString(
            "QProgressBar { background:%1; border-radius:5px; border:none; }"
            "QProgressBar::chunk { background:%2; border-radius:5px; }"
        ).arg(BORDER, b.color));
        QLabel* pct = new QLabel(QString("%1%").arg(b.pct));
        pct->setFixedWidth(36); pct->setAlignment(Qt::AlignRight|Qt::AlignVCenter);
        pct->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
        bRow->addWidget(lbl); bRow->addWidget(pb); bRow->addWidget(pct);
        bcl->addLayout(bRow); bcl->addSpacing(8);
    }
    lay->addWidget(barCard);
    lay->addStretch();
    scroll->setWidget(page);
    return scroll;
}

// ═══════════════════════════════════════════════════════
//  PAGE 6 — SNACK BAR
// ═══════════════════════════════════════════════════════
QWidget* MainWindow::makeSnackPage() {
    QWidget* page = new QWidget();
    QHBoxLayout* lay = new QHBoxLayout(page);
    lay->setContentsMargins(20,20,20,20); lay->setSpacing(14);

    // Menu
    QFrame* menuCard = card();
    QVBoxLayout* mcl = new QVBoxLayout(menuCard);
    mcl->setContentsMargins(16,14,16,14);
    mcl->addWidget(sectionTitle("🍿  Menu"));

    struct SnackItem { QString emoji; QString name; double price; QString color; };
    QVector<SnackItem> items = {
        {"🍿","Popcorn (Large)", 60, ACCENT},
        {"🥤","Soft Drink",      40, INFO},
        {"🧀","Nachos",          50, TEAL},
        {"🍫","Chocolate Bar",   25, PURPLE},
        {"🌭","Hot Dog",         70, RED},
    };

    QVector<QSpinBox*> qtys;
    QLabel* totalLbl = nullptr;

    auto updateTotal = [&]() {};  // forward declare

    for (auto& item : items) {
        QFrame* row = new QFrame();
        row->setStyleSheet(QString("background:%1; border:1px solid %2; border-radius:8px;").arg(SURFACE, BORDER));
        QHBoxLayout* rl = new QHBoxLayout(row);
        rl->setContentsMargins(12,10,12,10);
        QLabel* icon = new QLabel(item.emoji);
        icon->setStyleSheet("font-size:22px; background:transparent;");
        QVBoxLayout* info = new QVBoxLayout();
        QLabel* nm = new QLabel(item.name);
        nm->setStyleSheet(QString("font-size:13px; font-weight:bold; color:%1; background:transparent;").arg(TEXT));
        QLabel* pr = new QLabel(QString("%1 EGP").arg(item.price));
        pr->setStyleSheet(QString("font-size:11px; color:%1; background:transparent;").arg(item.color));
        info->addWidget(nm); info->addWidget(pr);
        QSpinBox* qty = new QSpinBox(); qty->setRange(0,20); qty->setValue(0);
        qty->setFixedWidth(70);
        qty->setStyleSheet(inputStyle());
        qtys.append(qty);
        rl->addWidget(icon); rl->addLayout(info); rl->addStretch(); rl->addWidget(qty);
        mcl->addWidget(row);
    }
    mcl->addStretch();
    lay->addWidget(menuCard, 3);

    // Order summary
    QFrame* sumCard = card();
    QVBoxLayout* scl = new QVBoxLayout(sumCard);
    scl->setContentsMargins(16,14,16,14);
    scl->addWidget(sectionTitle("🧾  Order Summary"));

    QWidget* sumList = new QWidget();
    QVBoxLayout* sll = new QVBoxLayout(sumList);
    sll->setContentsMargins(0,0,0,0); sll->setSpacing(4);
    scl->addWidget(sumList);
    scl->addStretch();

    QFrame* divLine = new QFrame(); divLine->setFrameShape(QFrame::HLine);
    divLine->setStyleSheet(QString("color:%1;").arg(BORDER));
    scl->addWidget(divLine);
    totalLbl = new QLabel("Total: 0 EGP");
    totalLbl->setAlignment(Qt::AlignCenter);
    totalLbl->setStyleSheet(QString(
        "font-size:26px; font-weight:bold; color:%1; background:transparent; border:none;"
    ).arg(ACCENT));
    scl->addWidget(totalLbl);
    scl->addSpacing(8);
    scl->addWidget(primaryBtn("✅  Place Order"));

    // Wire up totals
    for (int i = 0; i < qtys.size(); i++) {
        connect(qtys[i], QOverload<int>::of(&QSpinBox::valueChanged), this,
                [=, &items]() {
            double total = 0;
            // clear sumList
            QLayoutItem* child;
            while ((child = sll->takeAt(0)) != nullptr) {
                delete child->widget(); delete child;
            }
            for (int j = 0; j < qtys.size(); j++) {
                int q = qtys[j]->value();
                if (q > 0) {
                    double sub = q * items[j].price;
                    total += sub;
                    QLabel* line = new QLabel(QString("%1 × %2  →  %3 EGP")
                        .arg(items[j].name).arg(q).arg(sub));
                    line->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
                    sll->addWidget(line);
                }
            }
            if (sll->count() == 0) {
                QLabel* empty = new QLabel("No items selected yet.");
                empty->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
                sll->addWidget(empty);
            }
            totalLbl->setText(QString("Total: %1 EGP").arg(total));
        });
    }
    // Init
    QLabel* empty = new QLabel("No items selected yet.");
    empty->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
    sll->addWidget(empty);

    lay->addWidget(sumCard, 2);
    return page;
}

// ═══════════════════════════════════════════════════════
//  PAGE 7 — PARKING
// ═══════════════════════════════════════════════════════
QWidget* MainWindow::makeParkingPage() {
    QWidget* page = new QWidget();
    QHBoxLayout* lay = new QHBoxLayout(page);
    lay->setContentsMargins(20,20,20,20); lay->setSpacing(14);

    // Calculator
    QFrame* calcCard = card();
    QVBoxLayout* ccl = new QVBoxLayout(calcCard);
    ccl->setContentsMargins(20,18,20,18);
    ccl->addWidget(sectionTitle("🚗  Parking Fee Calculator"));
    ccl->addSpacing(8);

    QSpinBox* minBox = new QSpinBox(); minBox->setRange(15,480); minBox->setValue(150); minBox->setSuffix(" minutes");
    minBox->setStyleSheet(inputStyle());
    QLabel* minLbl = new QLabel("Duration:");
    minLbl->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));

    QSlider* slider = new QSlider(Qt::Horizontal);
    slider->setRange(15,480); slider->setValue(150); slider->setSingleStep(15);
    slider->setStyleSheet(QString(
        "QSlider::groove:horizontal { background:%1; height:6px; border-radius:3px; }"
        "QSlider::handle:horizontal { background:%2; width:16px; height:16px; margin:-5px 0; border-radius:8px; }"
        "QSlider::sub-page:horizontal { background:%2; border-radius:3px; }"
    ).arg(BORDER, ACCENT));

    // Big price display
    QLabel* feeDisplay = new QLabel("37.50 EGP");
    feeDisplay->setAlignment(Qt::AlignCenter);
    feeDisplay->setStyleSheet(QString(
        "font-size:42px; font-weight:bold; color:%1;"
        "background:%2; border-radius:12px; padding:20px;"
        "border:1px solid %3;"
    ).arg(ACCENT, SURFACE, BORDER));

    QLabel* rateLabel = new QLabel("Rate: 15 EGP / hour");
    rateLabel->setAlignment(Qt::AlignCenter);
    rateLabel->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));

    auto updateFee = [=]() {
        double fee = (minBox->value() / 60.0) * 15.0;
        feeDisplay->setText(QString("%1 EGP").arg(QString::number(fee,'f',2)));
    };
    connect(slider, &QSlider::valueChanged, this, [=](int v){ minBox->setValue(v); updateFee(); });
    connect(minBox, QOverload<int>::of(&QSpinBox::valueChanged), this, [=](int v){ slider->setValue(v); updateFee(); });

    ccl->addWidget(minLbl);
    ccl->addWidget(minBox);
    ccl->addSpacing(6);
    ccl->addWidget(slider);
    ccl->addSpacing(14);
    ccl->addWidget(feeDisplay);
    ccl->addWidget(rateLabel);
    ccl->addSpacing(14);
    ccl->addWidget(primaryBtn("✅  Confirm & Pay"));
    ccl->addStretch();
    lay->addWidget(calcCard, 2);

    // Stats
    QWidget* statsW = new QWidget();
    QVBoxLayout* sl = new QVBoxLayout(statsW);
    sl->setContentsMargins(0,0,0,0); sl->setSpacing(12);

    QHBoxLayout* pkStats = new QHBoxLayout(); pkStats->setSpacing(10);
    pkStats->addWidget(statCard("🚗  Vehicles Today", "42",    TEXT));
    pkStats->addWidget(statCard("💰  Revenue (EGP)",  "945",   ACCENT));
    sl->addLayout(pkStats);

    QFrame* distCard = card();
    QVBoxLayout* dcl = new QVBoxLayout(distCard);
    dcl->setContentsMargins(16,14,16,14);
    dcl->addWidget(sectionTitle("⏱️  Duration Distribution"));
    struct PBar { QString label; int pct; QString color; };
    for (auto& b : QVector<PBar>{{"0–60 min",45,TEAL},{"1–2 hours",35,ACCENT},{"2+ hours",20,PURPLE}}) {
        QHBoxLayout* bRow = new QHBoxLayout();
        QLabel* lbl = new QLabel(b.label); lbl->setFixedWidth(80);
        lbl->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
        QProgressBar* pb = new QProgressBar(); pb->setRange(0,100); pb->setValue(b.pct);
        pb->setTextVisible(false); pb->setFixedHeight(10);
        pb->setStyleSheet(QString(
            "QProgressBar { background:%1; border-radius:5px; border:none; }"
            "QProgressBar::chunk { background:%2; border-radius:5px; }"
        ).arg(BORDER, b.color));
        QLabel* pct = new QLabel(QString("%1%").arg(b.pct));
        pct->setFixedWidth(36); pct->setAlignment(Qt::AlignRight|Qt::AlignVCenter);
        pct->setStyleSheet(QString("color:%1; font-size:12px; background:transparent;").arg(MUTED));
        bRow->addWidget(lbl); bRow->addWidget(pb); bRow->addWidget(pct);
        dcl->addLayout(bRow); dcl->addSpacing(8);
    }
    sl->addWidget(distCard);
    sl->addStretch();
    lay->addWidget(statsW, 3);
    return page;
}
