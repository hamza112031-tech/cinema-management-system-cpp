#include "LoginWindow.h"
#include "MainWindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QGraphicsDropShadowEffect>

LoginWindow::LoginWindow(QWidget* parent) : QWidget(parent) {
    setWindowTitle("CineMax — Login");
    setFixedSize(420, 560);
    setStyleSheet("background-color: #0a0d14;");

    QVBoxLayout* root = new QVBoxLayout(this);
    root->setAlignment(Qt::AlignCenter);
    root->setContentsMargins(0, 0, 0, 0);

    QFrame* card = new QFrame(this);
    card->setFixedWidth(340);
    card->setStyleSheet(
        "QFrame {"
        "  background: #111520;"
        "  border: 1px solid #252d42;"
        "  border-radius: 16px;"
        "}"
    );

    QVBoxLayout* lay = new QVBoxLayout(card);
    lay->setSpacing(14);
    lay->setContentsMargins(32, 32, 32, 32);

    // Logo area
    QLabel* logoIcon = new QLabel("🎬");
    logoIcon->setAlignment(Qt::AlignCenter);
    logoIcon->setStyleSheet("font-size: 42px; background: transparent; border: none;");

    QLabel* title = new QLabel("CineMax");
    title->setAlignment(Qt::AlignCenter);
    title->setStyleSheet(
        "font-size: 24px; font-weight: bold;"
        "color: #e8ecf4; background: transparent; border: none;"
    );

    QLabel* subtitle = new QLabel("Management System");
    subtitle->setAlignment(Qt::AlignCenter);
    subtitle->setStyleSheet(
        "font-size: 13px; color: #e8a020;"
        "background: transparent; border: none; margin-bottom: 8px;"
    );

    // Role label
    QLabel* roleLabel = new QLabel("Select your role");
    roleLabel->setStyleSheet("color: #7a8499; font-size: 12px; background: transparent; border: none;");

    roleBox = new QComboBox();
    roleBox->addItems({"Owner", "Employee", "Customer"});
    roleBox->setStyleSheet(
        "QComboBox {"
        "  background: #171d2e; border: 1px solid #252d42;"
        "  border-radius: 8px; padding: 10px 14px;"
        "  color: #e8ecf4; font-size: 13px;"
        "}"
        "QComboBox::drop-down { border: none; }"
        "QComboBox QAbstractItemView {"
        "  background: #171d2e; color: #e8ecf4;"
        "  selection-background-color: #252d42;"
        "  border: 1px solid #252d42;"
        "}"
    );

    // Username
    QLabel* unLabel = new QLabel("Username");
    unLabel->setStyleSheet("color: #7a8499; font-size: 12px; background: transparent; border: none;");
    usernameEdit = new QLineEdit();
    usernameEdit->setPlaceholderText("Enter username");
    usernameEdit->setText("admin");
    usernameEdit->setStyleSheet(
        "QLineEdit {"
        "  background: #171d2e; border: 1px solid #252d42;"
        "  border-radius: 8px; padding: 10px 14px;"
        "  color: #e8ecf4; font-size: 13px;"
        "}"
        "QLineEdit:focus { border: 1px solid #e8a020; }"
    );

    // Password
    QLabel* pwLabel = new QLabel("Password");
    pwLabel->setStyleSheet("color: #7a8499; font-size: 12px; background: transparent; border: none;");
    passwordEdit = new QLineEdit();
    passwordEdit->setPlaceholderText("Enter password");
    passwordEdit->setText("admin123");
    passwordEdit->setEchoMode(QLineEdit::Password);
    passwordEdit->setStyleSheet(usernameEdit->styleSheet());

    // Error label
    errorLabel = new QLabel("");
    errorLabel->setAlignment(Qt::AlignCenter);
    errorLabel->setStyleSheet(
        "color: #e74c3c; font-size: 12px;"
        "background: rgba(231,76,60,0.1); border-radius: 6px;"
        "padding: 6px; border: none;"
    );
    errorLabel->hide();

    // Login button
    loginBtn = new QPushButton("Sign In");
    loginBtn->setCursor(Qt::PointingHandCursor);
    loginBtn->setFixedHeight(44);
    loginBtn->setStyleSheet(
        "QPushButton {"
        "  background: #e8a020; color: #000;"
        "  border: none; border-radius: 8px;"
        "  font-size: 14px; font-weight: bold;"
        "}"
        "QPushButton:hover { background: #d4911c; }"
        "QPushButton:pressed { background: #bf8218; }"
    );

    lay->addWidget(logoIcon);
    lay->addWidget(title);
    lay->addWidget(subtitle);
    lay->addWidget(roleLabel);
    lay->addWidget(roleBox);
    lay->addWidget(unLabel);
    lay->addWidget(usernameEdit);
    lay->addWidget(pwLabel);
    lay->addWidget(passwordEdit);
    lay->addWidget(errorLabel);
    lay->addWidget(loginBtn);

    root->addWidget(card);

    connect(loginBtn, &QPushButton::clicked, this, &LoginWindow::onLogin);
    connect(passwordEdit, &QLineEdit::returnPressed, this, &LoginWindow::onLogin);
}

void LoginWindow::onLogin() {
    QString user = usernameEdit->text().trimmed();
    QString pass = passwordEdit->text();

    if (user.isEmpty() || pass.isEmpty()) {
        errorLabel->setText("Please enter username and password.");
        errorLabel->show();
        return;
    }

    // Simple auth — in real project connect to DB
    if (pass == "admin123") {
        errorLabel->hide();
        emit loginSuccess(roleBox->currentText());
    } else {
        errorLabel->setText("Incorrect password. Try: admin123");
        errorLabel->show();
        passwordEdit->clear();
        passwordEdit->setFocus();
    }
}
