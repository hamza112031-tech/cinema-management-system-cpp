#include <QApplication>
#include <QScreen>
#include "LoginWindow.h"
#include "MainWindow.h"

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);
    app.setApplicationName("CineMax");
    app.setOrganizationName("OOP Project");

    // High-DPI support
    app.setAttribute(Qt::AA_UseHighDpiPixmaps);

    // Global font
    QFont font("Segoe UI", 10);
    app.setFont(font);

    // Show login window first
    LoginWindow* login = new LoginWindow();
    login->show();

    // Center on screen
    QScreen* screen = QApplication::primaryScreen();
    QRect sg = screen->availableGeometry();
    login->move(sg.center() - login->rect().center());

    MainWindow* mainWin = nullptr;

    QObject::connect(login, &LoginWindow::loginSuccess,
                     [&](const QString& role) {
        login->close();
        mainWin = new MainWindow();
        mainWin->setWindowTitle("CineMax — " + role + " Dashboard");
        mainWin->show();
        mainWin->resize(1200, 750);
        mainWin->move(sg.center() - mainWin->rect().center());
    });

    return app.exec();
}
